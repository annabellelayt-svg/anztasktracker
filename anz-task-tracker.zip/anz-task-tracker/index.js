const express = require('express');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data', 'state.json');

function readState() {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function writeState(state) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2));
}

// Send Google Chat webhook notification
function sendChatNotification(webhookUrl, message) {
    if (!webhookUrl) return;
    const payload = JSON.stringify({ text: message });
    const urlObj = new URL(webhookUrl);
    const lib = urlObj.protocol === 'https:' ? https : http;

    const req = lib.request(urlObj, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' }
    }, (res) => {
        res.resume(); // drain response
    });
    req.on('error', (err) => console.error('Webhook error:', err.message));
    req.write(payload);
    req.end();
}

// Get full state
app.get('/api/state', (req, res) => {
    res.json(readState());
});

// Create task
app.post('/api/tasks', (req, res) => {
    const state = readState();
    const task = {
        id: state.nextId++,
        status: 'To Do',
        created: new Date().toISOString(),
        ...req.body
    };
    state.tasks.push(task);
    writeState(state);

    // Notify on assignment
    if (task.assignee && state.webhookUrl) {
        const priority = task.priority || 'P3';
        const client = task.client ? ` (${task.client})` : '';
        const due = task.due ? ` · Due: ${task.due}` : '';
        sendChatNotification(state.webhookUrl,
            `📋 *New task assigned to ${task.assignee}*\n${task.name}${client}\nPriority: ${priority}${due}`
        );
    }

    res.json(task);
});

// Update task
app.put('/api/tasks/:id', (req, res) => {
    const state = readState();
    const id = parseInt(req.params.id);
    const idx = state.tasks.findIndex(t => t.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });

    const oldTask = { ...state.tasks[idx] };
    Object.assign(state.tasks[idx], req.body);
    const updatedTask = state.tasks[idx];
    writeState(state);

    // Notify if assignee changed
    if (state.webhookUrl && updatedTask.assignee && oldTask.assignee !== updatedTask.assignee) {
        const priority = updatedTask.priority || 'P3';
        const client = updatedTask.client ? ` (${updatedTask.client})` : '';
        sendChatNotification(state.webhookUrl,
            `🔄 *Task reassigned to ${updatedTask.assignee}*\n${updatedTask.name}${client}\nPriority: ${priority}`
        );
    }

    // Notify when task is completed
    if (state.webhookUrl && updatedTask.status === 'Done' && oldTask.status !== 'Done') {
        sendChatNotification(state.webhookUrl,
            `✅ *Task completed*\n${updatedTask.name}${updatedTask.assignee ? '\nCompleted by: ' + updatedTask.assignee : ''}`
        );
    }

    res.json(updatedTask);
});

// Delete task
app.delete('/api/tasks/:id', (req, res) => {
    const state = readState();
    state.tasks = state.tasks.filter(t => t.id !== parseInt(req.params.id));
    writeState(state);
    res.json({ ok: true });
});

// Update members
app.put('/api/members', (req, res) => {
    const state = readState();
    state.members = req.body.members;
    writeState(state);
    res.json({ ok: true });
});

// Update clients
app.put('/api/clients', (req, res) => {
    const state = readState();
    state.clients = req.body.clients;
    writeState(state);
    res.json({ ok: true });
});

// Update webhook URL
app.put('/api/webhook', (req, res) => {
    const state = readState();
    state.webhookUrl = req.body.webhookUrl || '';
    writeState(state);
    res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`ANZ Task Tracker running on port ${PORT}`));
